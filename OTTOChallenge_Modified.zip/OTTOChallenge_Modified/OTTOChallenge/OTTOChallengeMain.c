﻿#include <stdio.h>
#include <Windows.h>
#include <math.h>
#include "OTTOChallenge_Header.h"

static float Time_SNodeArray[1000][1000];
static float time_array[100] = { 0.0 };

unsigned int cnt = 0;
int arr[1000][3] = { 0, 0 };

struct NodeStruct mNodeStruct = { 0 };

void main()
{
    char tmp, tmp1;
    unsigned int i = 0, j = 0, iteration_count = 0, exit_iteration = 0, next_cnt=0;

    /**********Get Inputs*******************/
    scanf_s("%d", &cnt);

    /*** This loop checks the number of iterations***/
    do{
        /*****scan X,Y points and penalty***/
        while (i < cnt)
        {
            scanf_s("%d%c", &arr[i][j], &tmp);
            if ((tmp == '\t' || tmp == ' ') && j < 3)
            {
                j++;
            }
            else if (tmp == '\n' || j == 2)
            {
                i++;
                j = 0;
            }

        }
        /******scan 0 to quit te iteration****/
        scanf_s("%d%c", &next_cnt, &tmp1);
        if (next_cnt == 0 && tmp1 == '\n')
        {
            exit_iteration = 1;
        }
        /****Append the last position of array after scanned inputs with 100,100,WAITTIME***/
        arr[cnt][0] = arr[cnt][1] = 100;
        arr[cnt][2] = WAITTIME;

        /***Calculate time between each point to its next points**/
        for (i = 0; i <= cnt; i++)
        {
            Calculate_point_to_point_time(i);
        }
        i = 0;
        while (i <= cnt)
        {

            Calculate_Next_Nodes_Time(&mNodeStruct, i);
            i = mNodeStruct.Next_Node;
        }
        /***copy calculated time for display****/
        time_array[iteration_count] = mNodeStruct.TotalTime;
        
        iteration_count++;

        /****clear buffers for the next iteration****/
        memset(arr, 0, sizeof(arr));
        memset(&mNodeStruct, 0, sizeof(mNodeStruct));
        i = 0, j = 0;
        cnt = next_cnt;

    } while (!exit_iteration);

    printf("\nOutput \n");
    /*****Display the output****/
    for (i = 0; i < iteration_count; i++)
    {
        time_array[i] = roundf(time_array[i] * 1000) / 1000;
        printf("%0.3f \n", time_array[i]);
    }

    system("pause");
}

/***************Equation to get distance between 2 waypoints****************
****************          √(x2 − x1)2 + (y2 − y1)2         *****************
****This function is to calculate poit to point time and copy in an array***/
void Calculate_point_to_point_time(unsigned int SourceNodeCount)
{
    int i=0;
    double distance=0.0;
    float time=0.0;
    int array_size = cnt + 1 - (SourceNodeCount);
    
    for (i = 0; i < array_size; i++)
    {
        if (SourceNodeCount == 0)
        {
            distance = sqrt((pow((arr[SourceNodeCount + i][X_POINT]), 2)) +
                (pow((arr[SourceNodeCount + i][Y_POINT]), 2)));
        }
        else
        {
            distance = sqrt((pow((arr[SourceNodeCount + i][X_POINT] - arr[SourceNodeCount - 1][X_POINT]), 2)) +
                (pow((arr[SourceNodeCount + i][Y_POINT] - arr[SourceNodeCount - 1][Y_POINT]), 2)));
        }
        time = (float)distance / 2;    
        Time_SNodeArray[SourceNodeCount][i] = time;
    }
}

/*** This function determines which should be the next node and  ****
**** shortest time from current node to the determined next node ****/
void Calculate_Next_Nodes_Time(struct  NodeStruct *mNodeStruct, unsigned int i)
{
    int penalty = 0;
    unsigned int k = 0;
    float point_to_point_time, waitTime=0;
    mNodeStruct->penalty=0;
    mNodeStruct->point_to_point_time=0;
    mNodeStruct->waitTime=0;
    mNodeStruct->Next_Node++;
    
    if (i == cnt)
    {
        mNodeStruct->TotalTime += Time_SNodeArray[i][k] + WAITTIME;
    }
    else
    {
        for (k = 0; k <= (cnt - i); k++)
        {
            
            penalty += arr[mNodeStruct->Next_Node - 1][PENALITY];
            point_to_point_time = Time_SNodeArray[i][k];

            /***check if we can skip any nodes to save time by incurring penalty***/
            if ((point_to_point_time + Time_SNodeArray[i + k + 1][0] + WAITTIME) > (Time_SNodeArray[i][k + 1] + penalty))
            {
                mNodeStruct->Next_Node++;
                mNodeStruct->penalty += penalty;
                mNodeStruct->point_to_point_time = Time_SNodeArray[i][k + 1];
                mNodeStruct->waitTime = WAITTIME;
                if (mNodeStruct->Next_Node >= cnt)
                { 
                    break; 
                }
            }
            else
            {
                /***Do not skip as penalty is higher than the benefits of skipping nodes***/
                penalty -= arr[mNodeStruct->Next_Node - 1][PENALITY];
                mNodeStruct->penalty = penalty; 
                mNodeStruct->point_to_point_time = Time_SNodeArray[i][k];
                mNodeStruct->waitTime = WAITTIME;
                break;
            }
        }
        /***total time between 2 nodes = total penaly incurred + current to determened next node time + total wait time***/
        mNodeStruct->TotalTime += mNodeStruct->penalty + mNodeStruct->point_to_point_time + mNodeStruct->waitTime;
       
    }
}

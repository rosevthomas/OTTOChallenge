#ifndef OTTOChallenge_Header
#define OTTOChallenge_Header

#define PENALITY 2
#define WAITTIME 10
#define X_POINT 0
#define Y_POINT 1

struct NodeStruct{
    unsigned int Next_Node;
    float point_to_point_time;
    float waitTime;
    unsigned int penalty;
    float TotalTime;
};

void Calculate_point_to_point_time(unsigned int i);
void Calculate_Next_Nodes_Time(struct  NodeStruct *mNodeStruct, unsigned int i);
#endif